# VU QUANG NGUYEN 2018 
### Link to Server: [Github_VuQuangNguyen2016](https://vuquangnguyen2016.github.io/Webpage/) 
# Hinh anh Bo mon - Sinh vien

|STT |Ki Thuat hat nhan - Vat li hat nhan 2015 |Get|
|:--:|:--:|:--:|
|1  |   Hinh anh Bo mon - PTN.LinhTrung                            |   [Bo Mon](https://github.com/vuquangnguyen2018/WebStudio/issues/15)   - --- [P.TN](https://github.com/vuquangnguyen2018/WebStudio/issues/19 )          |
|2  |   HINH ANH LOP VLYK                           |   [View](https://github.com/vuquangnguyen2018/WebStudio/issues/3)             |
|3  |   Hinh Anh SV KTHN - VLHN 2015                |   [View](https://github.com/vuquangnguyen2018/WebStudio/issues/8)             |
|4  |   Sinh vien khoa 2014                         |   [SinhVien.k2014](https://github.com/vuquangnguyen2018/WebStudio/issues/5)   |
|5  |   HINH ANH THUC TAP DA LAT - KTHN.VLHN        |   [View](https://github.com/vuquangnguyen2018/WebStudio/issues/2)             |
|6  |   Ki yeu KTHN-VLYk - GiangDien2019        |   [View](https://github.com/vuquangnguyen2018/WebStudio/issues/20)             |
|7| Tot nghiep 2019 | [View](https://github.com/vuquangnguyen2018/WebStudio/issues/21)|




# Focus Destination

|STT |ID |Get|
|:--:|:--:|:--:|
|1  |   Thoi Tho Au - Xom doi                                                   |   [View](https://github.com/vuquangnguyen2018/WebStudio/issues/17)             |
|2  |   Hinh anh nam 3 -2018                                                    |   [View](https://github.com/vuquangnguyen2018/WebStudio/issues/4)              |
|3  |   Hinh anh tu thien Tra Vinh                                              |   [View](https://github.com/vuquangnguyen2018/WebStudio/issues/1)              |
|4  |   HocBongUFJ/Oct 23.2018                                                  |   [View](https://github.com/vuquangnguyen2018/WebStudio/issues/16)             |
|5  |   Nguyen Ngoc Ha My ref{Nguyen Ngoc Han Ny} - {Quang Nam - Oct.10.1995}          |   [View](https://github.com/vuquangnguyen2018/WebStudio/issues/13)             |



#### - [ID Card](https://github.com/vuquangnguyen2018/WebStudio/issues/12)
